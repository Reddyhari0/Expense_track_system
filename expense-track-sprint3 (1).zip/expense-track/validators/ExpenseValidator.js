const CATEGORIES = ['Food', 'Travel', 'Bills', 'Study', 'Business', 'Other'];
const PAYMENT_METHODS = ['Card', 'Cash', 'Bank transfer', 'Other'];

class ExpenseValidator {
  static isValidDate(str) {
    if (typeof str !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
    const [y, m, d] = str.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
  }

  // Returns { errors: {field: message}, values: {cleaned} }
  static validate(body = {}, today = new Date()) {
    const errors = {};
    const amountRaw = String(body.amount ?? '').trim();
    const date = String(body.expense_date ?? '').trim();
    const category = String(body.category ?? '').trim();
    const description = String(body.description ?? '').trim();
    const payment = String(body.payment_method ?? '').trim();

    if (/^-\d/.test(amountRaw)) {
      errors.amount = 'Amount must be greater than 0';
    } else if (!/^\d+(\.\d+)?$/.test(amountRaw)) {
      errors.amount = 'Enter an amount such as 12.50';
    } else if (!/^\d+(\.\d{1,2})?$/.test(amountRaw)) {
      errors.amount = 'Amount can have at most 2 decimal places';
    } else if (Number(amountRaw) <= 0) {
      errors.amount = 'Amount must be greater than 0';
    } else if (Number(amountRaw) > 99999999.99) {
      errors.amount = 'Amount is too large';
    }

    const limit = new Date(today.getTime());
    limit.setFullYear(limit.getFullYear() + 1);
    if (!ExpenseValidator.isValidDate(date) || date < '2000-01-01' || date > limit.toISOString().slice(0, 10)) {
      errors.expense_date = 'Enter a valid date';
    }
    if (!CATEGORIES.includes(category)) errors.category = 'Choose a category';
    if (description.length > 255) errors.description = 'Description is too long (max 255)';
    if (!PAYMENT_METHODS.includes(payment)) errors.payment_method = 'Choose a payment method';

    return {
      errors,
      values: { amount: amountRaw, expense_date: date, category, description, payment_method: payment },
    };
  }
}

ExpenseValidator.CATEGORIES = CATEGORIES;
ExpenseValidator.PAYMENT_METHODS = PAYMENT_METHODS;
module.exports = ExpenseValidator;
