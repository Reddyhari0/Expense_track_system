const express = require('express');
const C = require('../controllers/ExpenseController');
const router = express.Router();

// Wrap async handlers so errors reach the central (friendly) error handler
const h = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/', h(C.index));
router.get('/export.csv', h(C.exportCsv));
router.get('/new', C.newForm);
router.post('/', h(C.create));
router.get('/:id', h(C.show));
router.get('/:id/edit', h(C.editForm));
router.post('/:id/update', h(C.update));
router.get('/:id/delete', h(C.confirmDelete));
router.post('/:id/delete', h(C.destroy));

module.exports = router;
