# Sprint 3 test evidence

Run date: 2026-11-17 (UTC). Command: `node --test tests/*.test.js`
Environment: Node v22.23.4, MariaDB 10.11.14-MariaDB-0ubuntu0.24.04.1 (local sandbox), demo seed data (24 records).

**Not yet verified:** the Docker Compose stack against MySQL 8.4 and the manual/browser checks (360 px layout, keyboard use, peer usability). The team must run these and record the results below.

## Automated results: 33 passed, 0 failed (15 validator unit tests, 18 integration tests)

| ID | Story | Check | Result |
|---|---|---|---|
| I-01 | US-01 | create valid expense -> 302 and persisted | PASS |
| I-02 | US-01 | invalid amount -> 400, message shown, input kept, nothing saved | PASS |
| I-03 | US-02 | list shows record and total | PASS |
| I-04 | US-03 | edit form is pre-filled, update persists | PASS |
| I-05 | US-03 | invalid update -> 400 and DB unchanged | PASS |
| I-06 | US-04 | delete asks for confirmation; cancel (GET only) keeps record; confirm removes it | PASS |
| I-07 | US-08 | unknown / malformed ids give friendly 404 without stack trace | PASS |
| I-08 | US-05 | filter by category returns only that category | PASS |
| I-09 | US-05 | date range filter and from>to message | PASS |
| I-10 | - | description search treats SQL / wildcard characters as plain text | PASS |
| I-11 | - | unknown sort value falls back safely | PASS |
| I-12 | US-07 | sort by amount high to low is ordered | PASS |
| I-13 | US-06 | summary total equals SUM in database | PASS |
| I-14 | US-05 | filtered list total matches filtered rows | PASS |
| I-15 | US-10 | CSV export honours filters, has header, neutralises formulas | PASS |
| I-16 | - | XSS: script in description is escaped on output | PASS |
| I-17 | US-01 | persistence: record survives a new DB connection | PASS |
| I-18 | US-08 | unknown page gives friendly 404 | PASS |
| V-01 | - | valid input has no errors | PASS |
| V-02 | - | negative amount rejected with plan message | PASS |
| V-03 | - | zero amount rejected | PASS |
| V-04 | - | more than 2 decimals rejected | PASS |
| V-05 | - | non-numeric / script-like amount rejected | PASS |
| V-06 | - | huge amount rejected | PASS |
| V-07 | - | impossible calendar date rejected | PASS |
| V-08 | - | malformed date rejected | PASS |
| V-09 | - | date far in the future rejected | PASS |
| V-10 | - | unknown category rejected | PASS |
| V-11 | - | description over 255 chars rejected, 255 accepted | PASS |
| V-12 | - | description is trimmed and optional | PASS |
| V-13 | - | invalid payment method rejected | PASS |
| V-14 | - | leap day accepted | PASS |
| V-15 | - | several errors reported together | PASS |

## Manual checklist (team to complete - one row per tester)
| Check | Tester | Date | Pass/Fail | Notes |
|---|---|---|---|---|
| Add expense in the browser (US-01) | | | | |
| Edit and delete with confirmation (US-03, US-04) | | | | |
| Filter, sort and export CSV (US-05, US-07, US-10) | | | | |
| 360 px width, no sideways scroll (US-09) | | | | |
| Keyboard only: add an expense (accessibility) | | | | |
| Clean clone -> `docker compose up --build` works first time | | | | |
| 3-5 peers complete add / edit / delete (usability) | | | | |
