const Expense = require('../models/Expense');
const ExpenseValidator = require('../validators/ExpenseValidator');

const FLASH = { created: 'Expense saved.', updated: 'Expense updated.', deleted: 'Expense deleted.' };
const todayIso = () => new Date().toISOString().slice(0, 10);
const parseId = (v) => (/^[1-9]\d{0,9}$/.test(String(v)) ? Number(v) : null);
const opts = () => ({ categories: ExpenseValidator.CATEGORIES, methods: ExpenseValidator.PAYMENT_METHODS });

function readFilters(query) {
  const f = {
    category: ExpenseValidator.CATEGORIES.includes(query.category) ? query.category : '',
    from: ExpenseValidator.isValidDate(query.from) ? query.from : '',
    to: ExpenseValidator.isValidDate(query.to) ? query.to : '',
    q: String(query.q || '').trim().slice(0, 100),
  };
  const sort = Expense.SORTS[query.sort] ? query.sort : 'date_desc';
  let filterError = null;
  if (f.from && f.to && f.from > f.to) {
    filterError = "'From' date must not be after 'To' date";
    f.from = ''; f.to = '';
  }
  return { f, sort, filterError };
}

const toQs = (f, sort) =>
  new URLSearchParams(Object.entries({ ...f, sort }).filter(([, v]) => v)).toString();

class ExpenseController {
  static async index(req, res) {
    const { f, sort, filterError } = readFilters(req.query);
    const [expenses, totals] = await Promise.all([Expense.findAll(f, sort), Expense.totals(f)]);
    const flashText = FLASH[req.query.flash];
    res.render('expenses/index', {
      title: 'Expenses', expenses, totals, filters: f, sort, qs: toQs(f, sort),
      categories: ExpenseValidator.CATEGORIES,
      filtered: Boolean(f.category || f.from || f.to || f.q),
      flash: filterError ? { type: 'error', text: filterError } : flashText ? { type: 'success', text: flashText } : null,
    });
  }

  static newForm(req, res) {
    res.render('expenses/new', {
      title: 'Add expense', values: { expense_date: todayIso(), payment_method: 'Card' }, errors: {}, ...opts(),
    });
  }

  static async create(req, res) {
    const { errors, values } = ExpenseValidator.validate(req.body);
    if (Object.keys(errors).length) {
      return res.status(400).render('expenses/new', { title: 'Add expense', values, errors, ...opts() });
    }
    await Expense.create(values);
    res.redirect('/expenses?flash=created');
  }

  static async show(req, res) {
    const e = await ExpenseController.load(req, res);
    if (e) res.render('expenses/show', { title: 'Expense details', expense: e });
  }

  static async editForm(req, res) {
    const e = await ExpenseController.load(req, res);
    if (!e) return;
    res.render('expenses/edit', {
      title: 'Edit expense', id: e.expense_id,
      values: { ...e, amount: String(e.amount), description: e.description || '' }, errors: {}, ...opts(),
    });
  }

  static async update(req, res) {
    const e = await ExpenseController.load(req, res);
    if (!e) return;
    const { errors, values } = ExpenseValidator.validate(req.body);
    if (Object.keys(errors).length) {
      return res.status(400).render('expenses/edit', { title: 'Edit expense', id: e.expense_id, values, errors, ...opts() });
    }
    await Expense.update(e.expense_id, values);
    res.redirect('/expenses?flash=updated');
  }

  static async confirmDelete(req, res) {
    const e = await ExpenseController.load(req, res);
    if (e) res.render('expenses/delete', { title: 'Delete expense', expense: e });
  }

  static async destroy(req, res) {
    const e = await ExpenseController.load(req, res);
    if (!e) return;
    await Expense.delete(e.expense_id);
    res.redirect('/expenses?flash=deleted');
  }

  static async exportCsv(req, res) {
    const { f, sort } = readFilters(req.query);
    const rows = await Expense.findAll(f, sort);
    // Prefix risky leading characters so spreadsheets do not run cell values as formulas
    const cell = (v) => {
      let s = v == null ? '' : String(v);
      if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
      return '"' + s.replace(/"/g, '""') + '"';
    };
    const lines = ['Date,Category,Description,Payment method,Amount (GBP)'];
    for (const r of rows) {
      lines.push([r.expense_date, r.category, r.description, r.payment_method, Number(r.amount).toFixed(2)].map(cell).join(','));
    }
    res.set('Content-Type', 'text/csv; charset=utf-8');
    res.set('Content-Disposition', 'attachment; filename="expenses.csv"');
    res.send(lines.join('\r\n') + '\r\n');
  }

  // Validates :id, loads the record, renders a friendly 404 if missing
  static async load(req, res) {
    const id = parseId(req.params.id);
    const e = id ? await Expense.findById(id) : null;
    if (!e) {
      res.status(404).render('error', { title: 'Not found', heading: 'Expense not found', message: 'That expense does not exist or was already deleted.' });
      return null;
    }
    return e;
  }
}

module.exports = ExpenseController;
