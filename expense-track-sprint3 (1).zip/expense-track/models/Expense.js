const { pool } = require('../db/pool');

const SORTS = {
  date_desc: 'expense_date DESC, expense_id DESC',
  date_asc: 'expense_date ASC, expense_id ASC',
  amount_desc: 'amount DESC, expense_id DESC',
  amount_asc: 'amount ASC, expense_id ASC',
};

function escapeLike(s) {
  return s.replace(/[\\%_]/g, (c) => '\\' + c);
}

function buildWhere(f = {}) {
  const clauses = [];
  const params = [];
  if (f.category) { clauses.push('category = ?'); params.push(f.category); }
  if (f.from) { clauses.push('expense_date >= ?'); params.push(f.from); }
  if (f.to) { clauses.push('expense_date <= ?'); params.push(f.to); }
  if (f.q) { clauses.push('description LIKE ?'); params.push('%' + escapeLike(f.q) + '%'); }
  return { where: clauses.length ? 'WHERE ' + clauses.join(' AND ') : '', params };
}

class Expense {
  static async findAll(filters = {}, sort = 'date_desc') {
    const { where, params } = buildWhere(filters);
    const order = SORTS[sort] || SORTS.date_desc; // whitelist: never interpolate user input
    const [rows] = await pool.query(`SELECT * FROM expenses ${where} ORDER BY ${order}`, params);
    return rows;
  }

  static async findById(id) {
    const [rows] = await pool.query('SELECT * FROM expenses WHERE expense_id = ?', [id]);
    return rows[0] || null;
  }

  static async create(d) {
    const [res] = await pool.query(
      'INSERT INTO expenses (amount, expense_date, category, description, payment_method) VALUES (?, ?, ?, ?, ?)',
      [d.amount, d.expense_date, d.category, d.description || null, d.payment_method]
    );
    return res.insertId;
  }

  static async update(id, d) {
    const [res] = await pool.query(
      'UPDATE expenses SET amount = ?, expense_date = ?, category = ?, description = ?, payment_method = ? WHERE expense_id = ?',
      [d.amount, d.expense_date, d.category, d.description || null, d.payment_method, id]
    );
    return res.affectedRows > 0;
  }

  static async delete(id) {
    const [res] = await pool.query('DELETE FROM expenses WHERE expense_id = ?', [id]);
    return res.affectedRows > 0;
  }

  static async totals(filters = {}) {
    const { where, params } = buildWhere(filters);
    const [rows] = await pool.query(
      `SELECT COALESCE(SUM(amount), 0) AS total, COUNT(*) AS records FROM expenses ${where}`, params);
    return { total: rows[0].total, records: rows[0].records };
  }

  static async thisMonthTotal(monthKey) {
    const [rows] = await pool.query(
      "SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE DATE_FORMAT(expense_date, '%Y-%m') = ?", [monthKey]);
    return rows[0].total;
  }

  static async byCategory() {
    const [rows] = await pool.query(
      'SELECT category, SUM(amount) AS total, COUNT(*) AS records FROM expenses GROUP BY category ORDER BY total DESC');
    return rows;
  }

  static async byMonth() {
    const [rows] = await pool.query(
      "SELECT DATE_FORMAT(expense_date, '%Y-%m') AS month, SUM(amount) AS total, COUNT(*) AS records FROM expenses GROUP BY month ORDER BY month DESC");
    return rows;
  }
}

Expense.SORTS = SORTS;
module.exports = Expense;
