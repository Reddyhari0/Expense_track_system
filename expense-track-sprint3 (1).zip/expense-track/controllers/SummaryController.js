const Expense = require('../models/Expense');

class SummaryController {
  static async index(req, res) {
    const monthKey = new Date().toISOString().slice(0, 7);
    const [totals, month, byCategory, byMonth] = await Promise.all([
      Expense.totals(), Expense.thisMonthTotal(monthKey), Expense.byCategory(), Expense.byMonth(),
    ]);
    const max = Math.max(1, ...byCategory.map((c) => Number(c.total)));
    res.render('summary', {
      title: 'Summary', totals, month, monthKey,
      byCategory: byCategory.map((c) => ({ ...c, pct: Math.round((Number(c.total) / max) * 100) })),
      byMonth,
    });
  }
}
module.exports = SummaryController;
