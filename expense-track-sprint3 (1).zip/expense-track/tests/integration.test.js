// Needs a running MySQL/MariaDB with db/init.sql loaded and DB_* env vars set.
const test = require('node:test');
const assert = require('node:assert');
require('dotenv').config();

const skip = !process.env.DB_HOST && 'DB_HOST not set - skipping integration tests';
let server, base, pool;

const form = (o) => new URLSearchParams(o).toString();
const post = (path, body) => fetch(base + path, {
  method: 'POST', redirect: 'manual',
  headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form(body),
});
const get = (path) => fetch(base + path, { redirect: 'manual' });
const good = { amount: '12.50', expense_date: '2026-10-12', category: 'Food', description: 'ITEST lunch', payment_method: 'Cash' };
const idFrom = async (desc) => (await pool.query('SELECT expense_id FROM expenses WHERE description = ? ORDER BY expense_id DESC LIMIT 1', [desc]))[0][0]?.expense_id;

test.before(async () => {
  if (skip) return;
  const app = require('../app');
  pool = require('../db/pool').pool;
  await new Promise((r) => { server = app.listen(0, r); });
  base = 'http://127.0.0.1:' + server.address().port;
});
test.after(async () => {
  if (skip) return;
  await pool.query("DELETE FROM expenses WHERE description LIKE 'ITEST%'");
  server.closeAllConnections(); server.close(); await pool.end();
});

test('I-01 US-01 create valid expense -> 302 and persisted', { skip }, async () => {
  const r = await post('/expenses', good);
  assert.strictEqual(r.status, 302);
  assert.match(r.headers.get('location'), /flash=created/);
  assert.ok(await idFrom('ITEST lunch'));
});
test('I-02 US-01 invalid amount -> 400, message shown, input kept, nothing saved', { skip }, async () => {
  const [[{ n: before }]] = await pool.query('SELECT COUNT(*) n FROM expenses');
  const r = await post('/expenses', { ...good, amount: '-5', description: 'ITEST keepme' });
  const html = await r.text();
  assert.strictEqual(r.status, 400);
  assert.match(html, /Amount must be greater than 0/);
  assert.match(html, /ITEST keepme/);
  const [[{ n: after }]] = await pool.query('SELECT COUNT(*) n FROM expenses');
  assert.strictEqual(after, before);
});
test('I-03 US-02 list shows record and total', { skip }, async () => {
  const html = await (await get('/expenses')).text();
  assert.match(html, /ITEST lunch/);
  assert.match(html, /Total shown/);
});
test('I-04 US-03 edit form is pre-filled, update persists', { skip }, async () => {
  const id = await idFrom('ITEST lunch');
  const form1 = await (await get(`/expenses/${id}/edit`)).text();
  assert.match(form1, /value="12.5"|value="12.50"/);
  const r = await post(`/expenses/${id}/update`, { ...good, amount: '8.50', description: 'ITEST lunch' });
  assert.strictEqual(r.status, 302);
  const [[row]] = await pool.query('SELECT amount FROM expenses WHERE expense_id = ?', [id]);
  assert.strictEqual(Number(row.amount), 8.5);
});
test('I-05 US-03 invalid update -> 400 and DB unchanged', { skip }, async () => {
  const id = await idFrom('ITEST lunch');
  const r = await post(`/expenses/${id}/update`, { ...good, category: 'Nope' });
  assert.strictEqual(r.status, 400);
  const [[row]] = await pool.query('SELECT category FROM expenses WHERE expense_id = ?', [id]);
  assert.strictEqual(row.category, 'Food');
});
test('I-06 US-04 delete asks for confirmation; cancel (GET only) keeps record; confirm removes it', { skip }, async () => {
  await post('/expenses', { ...good, description: 'ITEST delete-me' });
  const id = await idFrom('ITEST delete-me');
  const page = await (await get(`/expenses/${id}/delete`)).text();
  assert.match(page, /Delete this expense\?/);
  assert.ok(await idFrom('ITEST delete-me'), 'record still exists after viewing confirmation');
  const r = await post(`/expenses/${id}/delete`, {});
  assert.strictEqual(r.status, 302);
  assert.strictEqual(await idFrom('ITEST delete-me'), undefined);
});
test('I-07 US-08 unknown / malformed ids give friendly 404 without stack trace', { skip }, async () => {
  for (const p of ['/expenses/999999', '/expenses/abc', '/expenses/0/edit', '/expenses/1;DROP/delete']) {
    const r = await get(p);
    const html = await r.text();
    assert.strictEqual(r.status, 404, p);
    assert.doesNotMatch(html, /at .*\.js|ER_|SELECT /);
  }
});
test('I-08 US-05 filter by category returns only that category', { skip }, async () => {
  await post('/expenses', { ...good, category: 'Travel', description: 'ITEST travel' });
  const html = await (await get('/expenses?category=Travel')).text();
  assert.match(html, /ITEST travel/);
  assert.doesNotMatch(html, /ITEST lunch/);
});
test('I-09 US-05 date range filter and from>to message', { skip }, async () => {
  const inRange = await (await get('/expenses?from=2026-10-12&to=2026-10-12&q=ITEST')).text();
  assert.match(inRange, /ITEST lunch/);
  const outRange = await (await get('/expenses?from=2020-01-01&to=2020-01-02&q=ITEST')).text();
  assert.match(outRange, /No expenses match/);
  const bad = await (await get('/expenses?from=2026-12-01&to=2026-01-01')).text();
  assert.match(bad, /must not be after/);
});
test('I-10 description search treats SQL / wildcard characters as plain text', { skip }, async () => {
  const r = await get("/expenses?q=" + encodeURIComponent("' OR 1=1 --"));
  assert.strictEqual(r.status, 200);
  assert.match(await r.text(), /No expenses match/);
  const r2 = await get('/expenses?q=%25');
  assert.strictEqual(r2.status, 200);
});
test('I-11 unknown sort value falls back safely', { skip }, async () => {
  assert.strictEqual((await get('/expenses?sort=amount;DROP TABLE expenses')).status, 200);
  const [[{ n }]] = await pool.query('SELECT COUNT(*) n FROM expenses');
  assert.ok(n > 0);
});
test('I-12 US-07 sort by amount high to low is ordered', { skip }, async () => {
  const csv = await (await get('/expenses/export.csv?sort=amount_desc')).text();
  const amounts = csv.trim().split('\r\n').slice(1).map((l) => Number(l.split(',').pop().replace(/"/g, '')));
  for (let i = 1; i < amounts.length; i++) assert.ok(amounts[i - 1] >= amounts[i]);
});
test('I-13 US-06 summary total equals SUM in database', { skip }, async () => {
  const [[{ t }]] = await pool.query('SELECT SUM(amount) t FROM expenses');
  const html = await (await get('/summary')).text();
  assert.ok(html.includes('£' + Number(t).toFixed(2)), 'summary shows £' + Number(t).toFixed(2));
});
test('I-14 US-05 filtered list total matches filtered rows', { skip }, async () => {
  const [[{ t }]] = await pool.query("SELECT SUM(amount) t FROM expenses WHERE category = 'Food'");
  const html = await (await get('/expenses?category=Food')).text();
  assert.ok(html.includes('£' + Number(t).toFixed(2)));
});
test('I-15 US-10 CSV export honours filters, has header, neutralises formulas', { skip }, async () => {
  await post('/expenses', { ...good, description: '=HYPERLINK("x")', category: 'Other' });
  const csv = await (await get('/expenses/export.csv?category=Other')).text();
  assert.match(csv, /^Date,Category,Description,Payment method,Amount \(GBP\)/);
  assert.doesNotMatch(csv, /Food/);
  assert.match(csv, /"'=HYPERLINK/);
  await pool.query("DELETE FROM expenses WHERE description LIKE '=HYPERLINK%'");
});
test('I-16 XSS: script in description is escaped on output', { skip }, async () => {
  await post('/expenses', { ...good, description: 'ITEST <script>alert(1)</script>' });
  const html = await (await get('/expenses?q=ITEST')).text();
  assert.doesNotMatch(html, /<script>alert\(1\)<\/script>/);
  assert.match(html, /&lt;script&gt;/);
});
test('I-17 US-01 persistence: record survives a new DB connection', { skip }, async () => {
  const mysql = require('mysql2/promise');
  const c = await mysql.createConnection({ host: process.env.DB_HOST, port: Number(process.env.DB_PORT || 3306), user: process.env.DB_USER, password: process.env.DB_PASSWORD, database: process.env.DB_NAME });
  const [rows] = await c.query("SELECT 1 FROM expenses WHERE description = 'ITEST lunch'");
  await c.end();
  assert.strictEqual(rows.length, 1);
});
test('I-18 US-08 unknown page gives friendly 404', { skip }, async () => {
  const r = await get('/nope');
  assert.strictEqual(r.status, 404);
  assert.match(await r.text(), /Page not found/);
});
