const express = require('express');
const C = require('../controllers/SummaryController');
const router = express.Router();
router.get('/', (req, res, next) => C.index(req, res).catch(next));
module.exports = router;
