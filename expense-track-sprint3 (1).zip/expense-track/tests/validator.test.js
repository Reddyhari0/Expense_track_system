const test = require('node:test');
const assert = require('node:assert');
const V = require('../validators/ExpenseValidator');

const good = { amount: '12.50', expense_date: '2026-10-12', category: 'Food', description: 'Lunch', payment_method: 'Card' };
const today = new Date('2026-11-17T12:00:00Z');
const run = (over) => V.validate({ ...good, ...over }, today);

test('V-01 valid input has no errors', () => assert.deepStrictEqual(run({}).errors, {}));
test('V-02 negative amount rejected with plan message', () => assert.strictEqual(run({ amount: '-5' }).errors.amount, 'Amount must be greater than 0'));
test('V-03 zero amount rejected', () => assert.strictEqual(run({ amount: '0' }).errors.amount, 'Amount must be greater than 0'));
test('V-04 more than 2 decimals rejected', () => assert.ok(run({ amount: '1.234' }).errors.amount));
test('V-05 non-numeric / script-like amount rejected', () => {
  assert.ok(run({ amount: 'abc' }).errors.amount);
  assert.ok(run({ amount: '<script>1</script>' }).errors.amount);
  assert.ok(run({ amount: '' }).errors.amount);
});
test('V-06 huge amount rejected', () => assert.ok(run({ amount: '999999999' }).errors.amount));
test('V-07 impossible calendar date rejected', () => assert.strictEqual(run({ expense_date: '2026-02-30' }).errors.expense_date, 'Enter a valid date'));
test('V-08 malformed date rejected', () => assert.ok(run({ expense_date: '12/10/2026' }).errors.expense_date));
test('V-09 date far in the future rejected', () => assert.ok(run({ expense_date: '2031-01-01' }).errors.expense_date));
test('V-10 unknown category rejected', () => assert.strictEqual(run({ category: 'Hacking' }).errors.category, 'Choose a category'));
test('V-11 description over 255 chars rejected, 255 accepted', () => {
  assert.strictEqual(run({ description: 'x'.repeat(256) }).errors.description, 'Description is too long (max 255)');
  assert.strictEqual(run({ description: 'x'.repeat(255) }).errors.description, undefined);
});
test('V-12 description is trimmed and optional', () => {
  assert.strictEqual(run({ description: '  Tea  ' }).values.description, 'Tea');
  assert.deepStrictEqual(run({ description: '' }).errors, {});
});
test('V-13 invalid payment method rejected', () => assert.ok(run({ payment_method: 'Bitcoin' }).errors.payment_method));
test('V-14 leap day accepted', () => assert.deepStrictEqual(run({ expense_date: '2024-02-29' }).errors, {}));
test('V-15 several errors reported together', () => assert.strictEqual(Object.keys(V.validate({}, today).errors).length, 4));
