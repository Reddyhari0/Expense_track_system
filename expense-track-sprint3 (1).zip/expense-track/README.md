# Expense Track System - Sprint 3

PUG + Node.js + Express + MySQL + Docker. Team LocalBoy Sairam (CMP-L004-0 Software Development 2).

## Run with Docker (clean clone)
1. `git clone <repository URL>` and `cd expense-track`
2. `copy .env.example .env` (Windows) or `cp .env.example .env`, then set local passwords
3. `docker compose up --build`
4. Open http://localhost:3000/expenses
5. Reset database: `docker compose down -v` then `docker compose up --build`

## Run without Docker
Install Node 20+ and MySQL 8, load `db/init.sql`, set `DB_HOST=localhost` and the other `DB_*` values in `.env`, then `npm install && npm start`.

## Tests
- `npm run test:unit` - validator tests (no database needed)
- `npm test` - unit + integration tests (needs the database and `DB_*` variables set)

## Structure
`app.js` · `routes/` · `controllers/` (ExpenseController, SummaryController) · `models/Expense.js` · `validators/ExpenseValidator.js` · `db/` (pool.js, init.sql) · `views/` (PUG) · `public/css/` · `tests/` · `docs/`

## Sprint 3 features
Create, read, edit (pre-filled), delete with confirmation page, server-side validation, filter (category, date range, description search), sort, spending summary (totals by category and month), CSV export (filtered), friendly 404/500 pages, responsive layout (360 px).
