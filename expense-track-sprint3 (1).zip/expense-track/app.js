require('dotenv').config();
const path = require('path');
const express = require('express');
const { waitUntilReady } = require('./db/pool');

const app = express();
app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));
app.disable('x-powered-by');

app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => res.redirect('/expenses'));
app.use('/expenses', require('./routes/expenses'));
app.use('/summary', require('./routes/summary'));

app.use((req, res) => {
  res.status(404).render('error', { title: 'Page not found', heading: 'Page not found', message: 'We could not find that page.' });
});

// Central error handler: log details server-side, never show stack traces or SQL to the user (US-08)
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).render('error', { title: 'Something went wrong', heading: 'Something went wrong', message: 'Please try again. If the problem continues, tell the team.' });
});

if (require.main === module) {
  const port = process.env.PORT || 3000;
  waitUntilReady().then(() => app.listen(port, () => console.log(`Expense Track running on :${port}`)))
    .catch((e) => { console.error(e.message); process.exit(1); });
}

module.exports = app;
